/*
const capitals = [
  'Kabul','Tirana','Algiers','Andorra la Vella','Luanda','Saint Johns','Buenos Aires','Yerevan','Canberra','Vienna','Baku','Nassau','Dhaka','Bridgetown','Minsk','Brussels','Belmopan','Porto-Novo','Thimphu','La Paz & Sucre','Sarajevo','Gaborone','Rio de Janeiro','Bandar Seri Begawan','Sofia','Ouagadougou','Gitega','Yamoussoukro','Praia','Phnom Penh','Yaoundé','Ottawa','Bangui',"N'Djamena",'Santiago','Beijing','Bogotá','Moroni','Kinshasa','San José','Zagreb','Havana','Nicosia','Prague','Kinshasa','Copenhagen','Djibouti City','Roseau','Santo Domingo','Quito','Cairo','San Salvador','Malabo','Asmara','Tallinn','Mbabane','Addis Ababa','Suva','Helsinki','Paris','Libreville','','','','','','',''
  
]
const capitals = ["Kabul","Tirana"];

function readOutLoud(message){
  const speech = new SpeechSynthesisUtterance();
  //Capital of countries if statements
  //speech.text = "I don't";
  
  if(message.includes("capital of Afghanistan")){
    const FinalText = capitals[0];
     //"The capital of Afghanistan is " +capitals[0];
    speech.text = FinalText;
    //speech.lang = 'ja-JP';
  }
  
  speech.volume = 1;
  speech.rate = 1.1;
  speech.pitch = 1;
  //speech.lang = 'en-US';
  synth.speak(speech);
}
*/
